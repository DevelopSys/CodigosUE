package com.example.hotelapi;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HotelapiApplicationTests {

	@Test
	void contextLoads() {
	}

}
